"""Versioned acquisition utilities."""
