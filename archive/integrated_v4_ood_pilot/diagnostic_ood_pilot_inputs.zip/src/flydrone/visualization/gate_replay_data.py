"""Verified, paired access to preserved steering-gate traces (no rendering)."""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np
import pandas as pd

from flydrone.data.acquire import file_hash
from flydrone.simulation.benchmark_integrated_v2 import load_config

GATES = {
    "EPG-Delta7": "epg_delta7",
    "Delta7-PFL3": "delta_pfl3",
    "Steering conjunto": "steering",
    "Piloto OOD": "ood_pilot",
}
CASE_KEYS = ["scenario", "target_bearing_deg", "initial_relative_heading_deg"]


@dataclass
class SavedFlight:
    controller: str
    episode: dict
    frame: pd.DataFrame
    path: Path

    def index_at(self, seconds: float) -> int:
        """Hold the last recorded sample; never extrapolate or wrap at the end."""
        return int(np.clip(np.searchsorted(self.frame.time_s, seconds, side="right") - 1,
                           0, len(self.frame) - 1))


class GateArchive:
    """Only expose cases for which both preserved traces actually exist."""

    def __init__(self, root: Path, gate: str):
        self.root = root
        self.slug = GATES[gate]
        self.is_ood = self.slug == "ood_pilot"
        config_name = ("quadrotor_integrated_v4_ood_pilot.yaml" if self.is_ood else
                       f"quadrotor_integrated_v4_{self.slug}_null_prospective.yaml")
        self.config = load_config(
            root, Path("configs") / config_name
        )
        self.folder = root / self.config["output"]
        archive_name = "integrated_v4_ood_pilot" if self.is_ood else f"integrated_v4_{self.slug}_null"
        preservation = root / "archive" / archive_name / "preservation-manifest.json"
        self.manifest = json.loads(preservation.read_text(encoding="utf-8"))
        self._verify(self.folder / "episodes.csv")
        self.episodes = pd.read_csv(self.folder / "episodes.csv")
        self.intact = "full_flywire_v4" if self.is_ood else self.config["steering_null_intact_condition"]["name"]
        self.nulls = sorted(name for name in self.episodes.controller.unique() if name != self.intact)
        self._rows: dict[tuple, tuple[dict, Path]] = {}
        for (controller, scenario), group in self.episodes.groupby(["controller", "scenario"], sort=False):
            for index, (_, row) in enumerate(group.iterrows()):
                path = self.folder / "traces" / f"{controller}__{scenario}__{index:02d}.npz"
                if path.is_file():
                    self._rows[(controller, *self.case_key(row))] = (row.to_dict(), path)

    @staticmethod
    def case_key(row) -> tuple:
        return (str(row["scenario"]), round(float(row["target_bearing_deg"]), 8),
                round(float(row["initial_relative_heading_deg"]), 8))

    def _verify(self, path: Path) -> None:
        relative = path.relative_to(self.root).as_posix()
        expected = self.manifest["result_files_sha256"].get(relative)
        if expected is None or file_hash(path) != expected:
            raise ValueError(f"Preserved trace/hash mismatch: {relative}")

    def paired_cases(self, other: str) -> list[tuple]:
        return [key[1:] for key in self._rows
                if key[0] == self.intact and (other, *key[1:]) in self._rows]

    def load(self, controller: str, case: tuple) -> SavedFlight:
        episode, path = self._rows[(controller, *case)]
        self._verify(path)
        with np.load(path, allow_pickle=False) as archive:
            frame = pd.DataFrame(archive["values"], columns=archive["columns"].tolist())
        required = ["time_s", "x_m", "y_m", "z_m", "yaw_rad", "observed_yaw_rad", "goal_rad"]
        if frame.empty or not all(name in frame for name in required):
            raise ValueError(f"Missing replay columns: {path.name}")
        if not np.isfinite(frame[required].to_numpy()).all() or np.any(np.diff(frame.time_s) <= 0):
            raise ValueError(f"Invalid trace timing/values: {path.name}")
        return SavedFlight(controller, episode, frame, path)
