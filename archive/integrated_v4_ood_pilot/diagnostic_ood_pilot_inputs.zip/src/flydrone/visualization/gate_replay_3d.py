"""Native 3D comparison of preserved steering-gate flights and neuronal activity."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import yaml
from direct.gui.DirectGui import DirectButton, DirectOptionMenu, DirectSlider
from direct.gui.OnscreenText import OnscreenText
from direct.showbase.ShowBase import ShowBase
from panda3d.core import BitMask32, ClockObject, Filename, PerspectiveLens, TextNode, loadPrcFileData

from flydrone.data.acquire import save_json
from flydrone.neural.epg_delta7 import EPGDelta7Candidate
from flydrone.neural.pfl2_steering import PFL2SteeringController
from flydrone.neural.steering_connectome_nulls import build_steering_null
from flydrone.neural.steering_interface import activity
from flydrone.neural.travel_direction_drift import TravelDirectionDriftController
from flydrone.visualization.desktop import FlyDroneDesktop, rate_activity_color, signed_activity_color
from flydrone.visualization.gate_replay_data import GATES, GateArchive


class GateReplay3D(ShowBase):
    """Replay exact saved positions and inputs; reconstruct only algebraic activity."""

    lines = FlyDroneDesktop.lines
    load_neurons = FlyDroneDesktop.load_neurons
    filter = FlyDroneDesktop.filter
    rotate = FlyDroneDesktop.rotate
    zoom = FlyDroneDesktop.zoom

    def __init__(self, root: Path, offscreen: bool = False):
        loadPrcFileData("", "window-title FlyDrone | ensayos 3D\nwin-size 1440 900\naudio-library-name null\nsync-video true")
        super().__init__(windowType="offscreen" if offscreen else None)
        self.root = root
        self.disableMouse()
        self.setBackgroundColor(.025, .04, .075)
        self.playing = False
        self.elapsed = 0.0
        self.speed = 1.0
        self.selected = 0
        self.case_index = 0
        self.setting_slider = False
        self.orientation = yaml.safe_load((root / "configs/orientation_candidate_v1.yaml").read_text())
        self.model = EPGDelta7Candidate(root, root / self.orientation["candidate_config"])
        self.pfl2_controller = PFL2SteeringController(root, root / "configs/pfl2_steering.yaml")
        self.drift_controller = TravelDirectionDriftController(root, root / "configs/travel_direction_drift.yaml")
        self.geometry, self.classes = {}, {}
        self.scene = self.render.attachNewNode("paired saved flights")
        self.scene.hide(BitMask32.bit(1))
        self.brain = self.render.attachNewNode("complete FlyWire morphologies")
        self.brain.hide(BitMask32.bit(0))
        self.cam.node().setCameraMask(BitMask32.bit(0))
        self.camNode.getDisplayRegion(0).setDimensions(0, .56, .25, .77)
        self.camLens.setAspectRatio(1440 * .56 / (900 * .52))
        lens = PerspectiveLens()
        lens.setAspectRatio(1440 * .44 / (900 * .52))
        lens.setNearFar(.1, 3000)
        lens.setFov(45)
        self.braincam = self.makeCamera(self.win, displayRegion=(.56, 1, .25, .77), lens=lens)
        self.braincam.reparentTo(self.render)
        self.braincam.node().setCameraMask(BitMask32.bit(1))
        self.load_neurons()
        self.world_case = self.scene.attachNewNode("case")
        self._build_ui()
        self.open_gate("EPG-Delta7")
        self.accept("space", self.toggle)
        self.accept("r", self.reset_replay)
        self.accept("arrow_left", self.seek, [-1.0])
        self.accept("arrow_right", self.seek, [1.0])
        self.accept("wheel_up", self.zoom, [.9])
        self.accept("wheel_down", self.zoom, [1.1])
        self.accept("escape", self.userExit)
        self.taskMgr.add(self.tick, "preserved_gate_replay")

    def label(self, text: str, x: float, y: float, scale: float = .035, color=(.82, .91, 1, 1)):
        return OnscreenText(text=text, pos=(x, y), scale=scale, fg=color,
                            align=TextNode.ALeft, mayChange=True)

    def _build_ui(self) -> None:
        button_style = {"frameColor": (.12, .20, .29, 1), "text_fg": (.85, .95, 1, 1),
                        "relief": 1, "pad": (.28, .16)}
        self.label("FlyDrone | comparacion de ensayos en 3D", -1.48, .93, .052)
        self.label("SIMULADO | FlyWire 783 | estabilizacion y sensores: ingenieria", -1.48, .85, .031)
        self.case_label = self.label("", -1.48, .72, .032)
        self.gate_stats = self.label("", .25, .84, .027)
        self.status = self.label("", -1.48, -.48, .031)
        self.neural_label = self.label("", .25, -.48, .029)
        self.legend = self.label("VERDE: intacto     NARANJA: comparacion     AMARILLO: meta", -1.48, -.58, .026)
        self.label("Morfologias completas | color: actividad global por neurona", .25, .72, .025)
        self.label("EPG/Delta7/FC2/PFL: reconstruida desde entradas guardadas\nPFN/hDeltaB: actividad registrada | sin propagacion por ramas",
                   .25, -.62, .025)
        self.label("Se muestran solo casos con ambas trazas guardadas. Resultados globales en el informe.",
                   -1.48, -.94, .026)
        self.gate_menu = DirectOptionMenu(items=list(GATES), initialitem=0,
                                          scale=.035, pos=(-1.48, 0, .63), command=self.open_gate)
        self.null_menu = DirectOptionMenu(items=["Cargando"], scale=.028, pos=(-.83, 0, .63))
        self.play_button = DirectButton(text="Reproducir", scale=.038, pos=(-1.25, 0, -.80), command=self.toggle, **button_style)
        DirectButton(text="Reiniciar", scale=.035, pos=(-.83, 0, -.80), command=self.reset_replay, **button_style)
        DirectButton(text="Caso anterior", scale=.031, pos=(-.40, 0, -.80), command=self.previous_case, **button_style)
        DirectButton(text="Caso siguiente", scale=.031, pos=(.07, 0, -.80), command=self.next_case, **button_style)
        DirectButton(text="Actividad A / B", scale=.032, pos=(.58, 0, -.80), command=self.switch_activity, **button_style)
        self.speed_menu = DirectOptionMenu(items=["0.5x", "1x", "2x", "4x"], initialitem=1,
                                           scale=.032, pos=(1.00, 0, -.80), command=self.change_speed)
        self.slider = DirectSlider(range=(0, 35), value=0, pageSize=1, scale=1.33,
                                   frameSize=(-1, 1, -.008, .008),
                                   frameColor=(.17, .26, .35, 1),
                                   thumb_frameSize=(-.012, .012, -.025, .025),
                                   thumb_frameColor=(.1, .85, .70, 1),
                                   pos=(0, 0, -.72), command=self.slider_changed)
        for index, kind in enumerate(["Todas", "EPG", "Delta7", "FC2", "PFL3", "PFL2", "PFN", "hDeltaB"]):
            DirectButton(text=kind, scale=.024, pos=(.32 + index * .16, 0, -.38),
                         command=self.filter, extraArgs=[kind], **button_style)
        DirectButton(text="Rotar -", scale=.025, pos=(.48, 0, -.87), command=self.rotate, extraArgs=[-15], **button_style)
        DirectButton(text="Rotar +", scale=.025, pos=(.85, 0, -.87), command=self.rotate, extraArgs=[15], **button_style)
        self.time_label = self.label("", -1.48, -.67, .029)

    def open_gate(self, label: str) -> None:
        self.archive = GateArchive(self.root, label)
        self.null_menu["items"] = self.archive.nulls
        self.null_menu["command"] = self.open_null
        self.null_menu.set(0, fCommand=0)
        self.open_null(self.archive.nulls[0])

    def open_null(self, name: str) -> None:
        self.other = name
        self.cases = self.archive.paired_cases(name)
        if not self.cases:
            raise ValueError("No preserved paired traces available for this condition")
        self.case_index = 0
        counts = self.archive.episodes.groupby("controller").success.agg(["sum", "size"])
        a, b = counts.loc[self.archive.intact], counts.loc[name]
        self.other_label = "convencional" if self.archive.is_ood else "nulo"
        title = "Piloto diagnostico" if self.archive.is_ood else "Gate completo"
        self.gate_stats.setText(f"{title}: A {int(a['sum'])}/{int(a['size'])} | B {int(b['sum'])}/{int(b['size'])}\n{name} | comparacion pareada")
        self.legend.setText(f"VERDE: intacto     NARANJA: {self.other_label}     AMARILLO: meta")
        self.variant = None
        if not self.archive.is_ood:
            seed = int(name.rsplit("_", 1)[1])
            template = self.archive.config["steering_null_condition_template"]
            self.variant = build_steering_null(
                self.model, seed, float(self.orientation["epg_heading_sign"]),
                float(self.orientation["phase_offset_deg"]),
                projection_mode=template.get("steering_null_projection", "both"),
            ).variant
        self.load_case()

    def load_case(self) -> None:
        self.playing = False
        case = self.cases[self.case_index]
        self.flights = [self.archive.load(controller, case)
                        for controller in (self.archive.intact, self.other)]
        self.activities = []
        self.reconstruction_errors = []
        for index, flight in enumerate(self.flights):
            frame = flight.frame
            if self.archive.is_ood and index == 1:
                self.activities.append({})
                continue
            values = activity(self.model, frame.observed_yaw_rad.to_numpy(), frame.goal_rad.to_numpy(),
                              self.orientation, None if index == 0 else self.variant)
            epg, delta, fc2, rates, signal = values
            base = np.clip(self.orientation["readout_gain_rad_per_s_per_hz"] * signal,
                           -self.orientation["maximum_yaw_rate_rad_s"], self.orientation["maximum_yaw_rate_rad_s"])
            predicted = np.clip(base * frame.pfl2_scale.to_numpy(),
                                -self.pfl2_controller.config["maximum_yaw_rate_rad_s"],
                                self.pfl2_controller.config["maximum_yaw_rate_rad_s"])
            error = float(np.max(np.abs(predicted - frame.yaw_command_rad_s.to_numpy())))
            if error > 1e-8:
                raise ValueError(f"Reconstructed steering differs from recorded command: {error}")
            self.reconstruction_errors.append(error)
            pfl2 = np.asarray([self.pfl2_controller.model.activity(h, g)
                               for h, g in zip(frame.observed_yaw_rad, frame.goal_rad)])
            mapping = {}
            for ids, array, rate in [
                (self.model.epg_ids, epg, False), (self.model.base.delta_ids, delta, False),
                (self.model.base.fc2_ids, fc2, False), (self.model.base.pfl3.root_id, rates, True),
                (self.pfl2_controller.model.pfl2_ids, pfl2, True),
                (self.drift_controller.model.pfn.root_id, frame.filter(regex=r"^pfn_activity_\d+$").to_numpy(), False),
                (self.drift_controller.model.hdelta.root_id, frame.filter(regex=r"^hdelta_activity_\d+$").to_numpy(), False),
            ]:
                if len(ids) != array.shape[1]:
                    raise ValueError("Activity dimensions differ from preserved neuron ordering")
                for column, rid in enumerate(ids):
                    mapping[str(rid)] = (array[:, column], rate, 40.0 if rate and str(rid) in set(self.model.base.pfl3.root_id.astype(str)) else 1.0)
            self.activities.append(mapping)
        self.duration = min(float(f.frame.time_s.iloc[-1]) for f in self.flights)
        self.slider["range"] = (0, self.duration)
        bearing = np.deg2rad(case[1])
        self.target = np.array([np.cos(bearing), np.sin(bearing)]) * self.archive.config["target_distance_m"]
        self._build_case_world()
        self.reset_replay()

    def _build_case_world(self) -> None:
        self.world_case.removeNode()
        self.world_case = self.scene.attachNewNode("paired saved world")
        points = np.concatenate([f.frame[["x_m", "y_m", "z_m"]].to_numpy() for f in self.flights])
        low = np.minimum(points[:, :2].min(axis=0), self.target)
        high = np.maximum(points[:, :2].max(axis=0), self.target)
        center = (low + high) / 2
        extent = max(7., float(np.max(high - low)) + 3.)
        spacing = max(1., float(np.ceil(extent / 14)))
        grid = []
        for offset in np.arange(-extent / 2, extent / 2 + spacing, spacing):
            grid.extend([((center[0] + offset, center[1] - extent/2, 0), (center[0] + offset, center[1] + extent/2, 0)),
                         ((center[0] - extent/2, center[1] + offset, 0), (center[0] + extent/2, center[1] + offset, 0))])
        self.lines(self.world_case, "floor", grid, (.15, .24, .34, 1), 1)
        self.camera.setPos(center[0] + extent * .65, center[1] - extent * 1.05, extent * .85)
        self.camera.lookAt(center[0], center[1], 1.)
        ring = [(self.target[0] + .3*np.cos(t), self.target[1] + .3*np.sin(t), 2.)
                for t in np.linspace(0, 2*np.pi, 49)]
        self.lines(self.world_case, "goal", list(zip(ring[:-1], ring[1:])), (1., .84, .15, 1), 4)
        self.drones, self.trails = [], []
        for index, flight in enumerate(self.flights):
            color = (.12, 1., .63, 1) if index == 0 else (1., .42, .14, 1)
            drone = self.world_case.attachNewNode(flight.controller)
            self.lines(drone, "arms", [((-.4,-.4,0),(.4,.4,0)),((-.4,.4,0),(.4,-.4,0))], color, 5)
            self.lines(drone, "heading", [((0,0,.06),(.75,0,.06)),((.75,0,.06),(.55,.13,.06)),((.75,0,.06),(.55,-.13,.06))], color, 4)
            for x, y in [(-.4,-.4),(-.4,.4),(.4,-.4),(.4,.4)]:
                ring = [(x+.18*np.cos(t),y+.18*np.sin(t),0) for t in np.linspace(0,2*np.pi,25)]
                self.lines(drone, "rotor", list(zip(ring[:-1],ring[1:])), color, 2)
            coords = flight.frame[["x_m", "y_m", "z_m"]].to_numpy()
            # Trajectory is shown in full and labelled as saved replay, without resimulation.
            self.lines(self.world_case, "full saved trajectory", list(zip(coords[:-1], coords[1:])), (*color[:3], .35), 1)
            self.drones.append(drone)
            self.trails.append(None)

    def render_at(self, seconds: float) -> None:
        self.elapsed = float(np.clip(seconds, 0, self.duration))
        rows = []
        for drone, flight in zip(self.drones, self.flights):
            row = flight.frame.iloc[flight.index_at(self.elapsed)]
            drone.setPos(float(row.x_m), float(row.y_m), float(row.z_m))
            drone.setH(float(np.rad2deg(row.yaw_rad)))
            rows.append(row)
        frame_index = self.flights[self.selected].index_at(self.elapsed)
        for rid, node in self.geometry.items():
            item = self.activities[self.selected].get(rid)
            if item is None:
                node.setColor(.2, .25, .32, 1)
            else:
                values, rate, scale = item
                color = rate_activity_color(values[frame_index], scale) if rate else signed_activity_color(values[frame_index], scale)
                node.setColor(*color)
        distances = [float(np.hypot(row.x_m-self.target[0], row.y_m-self.target[1])) for row in rows]
        outcomes = ["llego" if f.episode["success"] else "no llego" for f in self.flights]
        case = self.cases[self.case_index]
        self.case_label.setText(f"Caso guardado {self.case_index+1}/{len(self.cases)} | meta {case[1]:.0f} | heading {case[2]:.0f}\n{case[0]}")
        self.status.setText(f"A intacto: {distances[0]:.2f} m | resultado final: {outcomes[0]}\nB {self.other_label}: {distances[1]:.2f} m | resultado final: {outcomes[1]}\nTrayectorias completas guardadas | actitud visible: yaw")
        row = rows[self.selected]
        source = "A intacto" if self.selected == 0 else f"B {self.other_label}"
        rate_note = "Control convencional: actividad neuronal no definida"
        if self.activities[self.selected]:
            model_rates = np.array([self.activities[self.selected][str(rid)][0][frame_index]
                                    for rid in self.model.base.pfl3.root_id])
            left, right = float(model_rates[self.model.base.left].sum()), float(model_rates[self.model.base.right].sum())
            rate_note = f"PFL3 L {left:.1f} Hz | R {right:.1f} Hz | R-L {right-left:+.1f}"
        self.neural_label.setText(f"Actividad: {source} | yaw {row.yaw_command_rad_s:+.2f} rad/s\n{rate_note}\nHeading: {'ausente' if row.heading_dropout else 'disponible'} | velocidad: {'disponible' if row.position_available else 'ausente'}\nLlegada: {'retenida' if row.arrival_latched else 'en camino'} | motor medio {np.mean([row[f'motor_{i}_n'] for i in range(4)]):.2f} N")
        self.time_label.setText(f"t = {self.elapsed:05.2f} / {self.duration:.2f} s | {'reproduciendo' if self.playing else 'pausado'}")
        self.play_button["text"] = "Pausar" if self.playing else "Reproducir"
        self.setting_slider = True
        self.slider["value"] = self.elapsed
        self.setting_slider = False

    def slider_changed(self) -> None:
        if not self.setting_slider and hasattr(self, "flights"):
            self.render_at(float(self.slider["value"]))

    def toggle(self) -> None:
        if self.elapsed >= self.duration:
            self.elapsed = 0.
        self.playing = not self.playing
        self.render_at(self.elapsed)

    def reset_replay(self) -> None:
        self.playing = False
        self.render_at(0.)

    def seek(self, delta: float) -> None:
        self.render_at(self.elapsed + delta)

    def previous_case(self) -> None:
        self.case_index = (self.case_index - 1) % len(self.cases)
        self.load_case()

    def next_case(self) -> None:
        self.case_index = (self.case_index + 1) % len(self.cases)
        self.load_case()

    def switch_activity(self) -> None:
        self.selected = 1 - self.selected
        self.render_at(self.elapsed)

    def change_speed(self, label: str) -> None:
        self.speed = float(label[:-1])

    def tick(self, task):
        if self.playing:
            seconds = self.elapsed + min(.1, ClockObject.getGlobalClock().getDt()) * self.speed
            if seconds >= self.duration:
                self.playing = False
            self.render_at(seconds)
        return task.cont


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke-test", action="store_true")
    parser.add_argument("--audit-all", action="store_true", help="Check every preserved null in all three gates")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[3]
    app = GateReplay3D(root, offscreen=args.smoke_test)
    if args.smoke_test:
        folder = root / "results/desktop/gate-replay-3d"
        folder.mkdir(parents=True, exist_ok=True)
        checks = []
        for gate in GATES:
            app.open_gate(gate)
            for selected in (0, 1):
                app.selected = selected
                app.render_at(15.0)
                app.graphicsEngine.renderFrame()
                app.graphicsEngine.renderFrame()
                screenshot = folder / f"{app.archive.slug}-{'intact' if selected == 0 else 'null'}.png"
                if not app.win.saveScreenshot(Filename.fromOsSpecific(str(screenshot))):
                    raise RuntimeError(f"Screenshot could not be saved: {screenshot}")
                checks.append({"gate": gate, "selected": selected, "case": app.cases[app.case_index],
                               "geometry": app.geometry_report,
                               "maximum_yaw_reconstruction_error_rad_s": max(app.reconstruction_errors),
                               "traces": [f.path.relative_to(root).as_posix() for f in app.flights]})
            if args.audit_all and app.archive.is_ood:
                for _ in app.cases:
                    app.next_case()
                    app.render_at(app.duration)
                    checks.append({"gate": gate, "case": app.cases[app.case_index],
                                   "maximum_yaw_reconstruction_error_rad_s": max(app.reconstruction_errors)})
            elif args.audit_all:
                for name in app.archive.nulls[1:]:
                    app.open_null(name)
                    app.switch_activity()
                    app.seek(app.duration)
                    assert np.isclose(app.elapsed, app.duration)
                    app.reset_replay()
                    app.next_case()
                    app.previous_case()
                    app.slider["value"] = 5.
                    app.slider_changed()
                    assert np.isclose(app.elapsed, 5.)
                    checks.append({"gate": gate, "null": name,
                                   "maximum_yaw_reconstruction_error_rad_s": max(app.reconstruction_errors),
                                   "paired_saved_cases": len(app.cases)})
        save_json(folder / "smoke-report.json", {"checks": checks, "mode": "preserved replay"})
        app.destroy()
        print(f"Verified {len(checks)} rendered gate/activity combinations.")
    else:
        app.run()


if __name__ == "__main__":
    main()
