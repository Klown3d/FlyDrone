"""Predictive engineering safety barrier over observed range-hit points."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml


@dataclass(frozen=True)
class BarrierCommand:
    correction_xy_m_s2: tuple[float, float]
    speed_fraction: float
    predicted_clearance_m: float
    active: bool
    source: str = "engineering_predictive_range_barrier"


class InflatedPointBarrier:
    """Protect a swept point-mass path from inflated observed surface hits.

    Input points must come from sensing or its short-lived local map. Ground-truth
    obstacle centers are deliberately not accepted by this interface.
    """

    def __init__(self, config_path: Path):
        self.config_path = Path(config_path)
        self.config = yaml.safe_load(self.config_path.read_text(encoding="utf-8"))
        if self.config.get("parameter_status") != "engineering_predictive_range_barrier_not_neural":
            raise ValueError("Range barrier configuration must declare its engineering status")
        horizon = float(self.config["prediction_horizon_s"])
        inflated = float(self.config["inflated_clearance_m"])
        activation = float(self.config["activation_clearance_m"])
        maximum = float(self.config["maximum_correction_m_s2"])
        minimum_speed = float(self.config["minimum_speed_fraction"])
        if horizon <= 0 or inflated <= 0 or activation <= inflated or maximum <= 0:
            raise ValueError("Invalid predictive range barrier geometry")
        if not 0 <= minimum_speed <= 1:
            raise ValueError("minimum_speed_fraction must be in [0, 1]")

    def command(self, position_xy_m: tuple[float, float],
                velocity_xy_m_s: tuple[float, float],
                observed_hit_points_xy_m: np.ndarray) -> BarrierCommand:
        position = np.asarray(position_xy_m, dtype=float)
        velocity = np.asarray(velocity_xy_m_s, dtype=float)
        points = np.asarray(observed_hit_points_xy_m, dtype=float)
        if position.shape != (2,) or velocity.shape != (2,) or not np.isfinite(position).all() or not np.isfinite(velocity).all():
            raise ValueError("Barrier pose and velocity must be finite 2D vectors")
        if points.size == 0:
            return BarrierCommand((0.0, 0.0), 1.0, float("inf"), False)
        if points.ndim != 2 or points.shape[1] != 2 or not np.isfinite(points).all():
            raise ValueError("Barrier hit points must be a finite Nx2 array")

        segment = velocity * float(self.config["prediction_horizon_s"])
        length_squared = float(segment @ segment)
        offsets = points - position
        if length_squared <= 1e-12:
            parameters = np.zeros(len(points))
        else:
            parameters = np.clip((offsets @ segment) / length_squared, 0.0, 1.0)
        closest_path = position + parameters[:, None] * segment
        distances = np.linalg.norm(closest_path - points, axis=1)
        nearest = int(np.argmin(distances))
        predicted_clearance = float(distances[nearest])
        activation = float(self.config["activation_clearance_m"])
        if predicted_clearance >= activation:
            return BarrierCommand((0.0, 0.0), 1.0, predicted_clearance, False)

        inflated = float(self.config["inflated_clearance_m"])
        threat = float(np.clip((activation - predicted_clearance) /
                               (activation - inflated), 0.0, 1.0))
        away = position - points[nearest]
        norm = float(np.linalg.norm(away))
        if norm <= 1e-9:
            away = closest_path[nearest] - points[nearest]
            norm = float(np.linalg.norm(away))
        if norm <= 1e-9:
            away = -segment
            norm = float(np.linalg.norm(away))
        if norm <= 1e-9:
            away = np.array([1.0, 0.0])
            norm = 1.0
        magnitude = threat * float(self.config["maximum_correction_m_s2"])
        correction = away * (magnitude / norm)
        minimum_speed = float(self.config["minimum_speed_fraction"])
        speed_fraction = max(minimum_speed, 1.0 - threat)
        return BarrierCommand((float(correction[0]), float(correction[1])),
                              float(speed_fraction), predicted_clearance, True)
